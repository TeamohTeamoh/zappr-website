let video = document.getElementById('video');
let canvas = document.getElementById('canvas');
let ctx = canvas.getContext('2d');
let statusDiv = document.getElementById('status');
let scanOverlay = document.getElementById('scanOverlay');

let stream = null;
let scanning = false;
let lastScannedCode = null;
let lastScanTime = 0;

// Status-Nachrichten anzeigen
function showStatus(message, type = 'info') {
  statusDiv.textContent = message;
  statusDiv.className = `status-message ${type}`;
  statusDiv.style.display = 'block';
}

// Webcam starten
async function startCamera() {
  try {
    // No status message on start - only show on errors
    
    // Camera access with optimal settings
    const constraints = {
      video: {
        facingMode: 'environment',  // Rückkamera auf Mobilgeräten
        width: { ideal: 1280 },
        height: { ideal: 720 }
      }
    };
    
    stream = await navigator.mediaDevices.getUserMedia(constraints);
    
    video.srcObject = stream;
    video.setAttribute('playsinline', true);
    scanOverlay.style.display = 'block';
    
    // No success message - just start
    statusDiv.style.display = 'none';
    
    // Start scanning after video is ready
    video.addEventListener('loadedmetadata', () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      scanning = true;
      console.log('Started QR code scanning...', canvas.width, 'x', canvas.height);
      requestAnimationFrame(scanQRCode);
    }, { once: true });
    
  } catch (err) {
    console.error('Camera access error:', err);
    
    let errorMsg = '❌ Error: ';
    if (err.name === 'NotAllowedError') {
      errorMsg += 'Camera access denied. Please allow camera access in browser settings.';
    } else if (err.name === 'NotFoundError') {
      errorMsg += 'No camera found. Please ensure a camera is connected.';
    } else if (err.name === 'NotReadableError') {
      errorMsg += 'Camera is already being used by another application.';
    } else {
      errorMsg += 'Could not start camera: ' + err.message;
    }
    
    showStatus(errorMsg, 'error');
  }
}

// Scan QR code
function scanQRCode() {
  if (!scanning) return;
  
  if (video.readyState === video.HAVE_ENOUGH_DATA) {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    
    // Improved QR code detection with multiple attempts
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: "attemptBoth",  // Try normal and inverted images
    });
    
    if (code && code.data) {
      const currentTime = Date.now();
      
      // Only process if it's a new code or enough time has passed
      if (code.data !== lastScannedCode || currentTime - lastScanTime > 5000) {
        lastScannedCode = code.data;
        lastScanTime = currentTime;
        console.log('QR code detected:', code.data);
        handleQRCode(code.data);
      }
    }
  }
  
  requestAnimationFrame(scanQRCode);
}

// Process QR code
function handleQRCode(data) {
  console.log('QR code detected:', data);
  
  // Check if it's a URL
  if (isValidURL(data)) {
    // No success message - open directly
    
    // Normalize URL if no protocol
    let url = data;
    if (!data.startsWith('http://') && !data.startsWith('https://')) {
      url = 'https://' + data;
    }
    
    // Stop camera
    scanning = false;
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    
    // Open in same tab
    window.location.href = url;
    
  } else {
    showStatus('ℹ️ QR code contains no URL: ' + (data.length > 50 ? data.substring(0, 50) + '...' : data), 'info');
    // Allow scanning non-URLs again after 3 seconds
    setTimeout(() => {
      lastScannedCode = null;
      statusDiv.style.display = 'none';
    }, 3000);
  }
}

// URL validation
function isValidURL(string) {
  try {
    const url = new URL(string);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (_) {
    // If no protocol, check if it looks like a URL
    if (string.includes('.') && !string.includes(' ') && string.length > 3) {
      // Could be a domain (e.g. "google.com")
      return true;
    }
    return false;
  }
}

// Cleanup when leaving the page
window.addEventListener('beforeunload', () => {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
  }
});

// AUTOSTART: Start camera automatically when page loads
window.addEventListener('DOMContentLoaded', () => {
  console.log('Page loaded, starting camera automatically...');
  startCamera();
});

