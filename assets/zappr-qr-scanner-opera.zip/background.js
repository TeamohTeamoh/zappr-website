// Background Service Worker für Chrome Extension
// Öffnet die Scanner-Seite wenn auf den Button geklickt wird

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("scanner/scanner.html")
  });
});
